#!/usr/bin/env python3
"""
Extract detailed data from MDN Web Docs using web scraping.
Focuses on HTML, CSS, and JavaScript documentation.
"""

import os
import json
import logging
import requests
from pathlib import Path
from bs4 import BeautifulSoup
import time
import random

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(Path(__file__).parent.parent / 'logs' / 'extraction.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('extract_mdn_docs')

def load_config():
    """Load configuration from sources.json file."""
    config_path = Path(__file__).parent.parent / 'config' / 'sources.json'
    try:
        with open(config_path, 'r') as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Failed to load configuration: {e}")
        raise

def load_extracted_data(file_path):
    """Load previously extracted data."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Failed to load extracted data from {file_path}: {e}")
        return []

def fetch_page(url):
    """Fetch a page from MDN Web Docs."""
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        return response.text
    except Exception as e:
        logger.error(f"Failed to fetch page {url}: {e}")
        return None

def extract_html_element_details(element_data, config):
    """Extract detailed information for an HTML element from MDN Web Docs."""
    if not element_data.get('mdn_url'):
        logger.warning(f"No MDN URL for HTML element {element_data.get('tag_name')}")
        return element_data
    
    url = element_data['mdn_url']
    logger.info(f"Fetching details for HTML element {element_data['tag_name']} from {url}")
    
    html_content = fetch_page(url)
    if not html_content:
        return element_data
    
    soup = BeautifulSoup(html_content, 'html.parser')
    
    # Extract description
    description_section = soup.select_one('article section')
    if description_section:
        description = description_section.get_text(strip=True)
        element_data['description'] = description
    
    # Extract specification URL
    spec_link = soup.select_one('a[href*="spec.whatwg.org"], a[href*="w3.org/TR/"]')
    if spec_link:
        element_data['spec_url'] = spec_link['href']
    
    # Extract categories/content model
    content_model = {}
    content_categories = soup.find(string=lambda text: 'Content categories' in text if text else False)
    if content_categories:
        categories_parent = content_categories.find_parent('dt')
        if categories_parent and categories_parent.find_next_sibling('dd'):
            content_model['categories'] = categories_parent.find_next_sibling('dd').get_text(strip=True)
    
    permitted_content = soup.find(string=lambda text: 'Permitted content' in text if text else False)
    if permitted_content:
        content_parent = permitted_content.find_parent('dt')
        if content_parent and content_parent.find_next_sibling('dd'):
            content_model['permitted_children'] = content_parent.find_next_sibling('dd').get_text(strip=True)
    
    permitted_parents = soup.find(string=lambda text: 'Permitted parents' in text if text else False)
    if permitted_parents:
        parents_parent = permitted_parents.find_parent('dt')
        if parents_parent and parents_parent.find_next_sibling('dd'):
            content_model['permitted_parents'] = parents_parent.find_next_sibling('dd').get_text(strip=True)
    
    if content_model:
        element_data['content_model'] = content_model
    
    # Extract DOM interface
    dom_interface = soup.find(string=lambda text: 'DOM interface' in text if text else False)
    if dom_interface:
        interface_parent = dom_interface.find_parent('dt')
        if interface_parent and interface_parent.find_next_sibling('dd'):
            element_data['dom_interface'] = interface_parent.find_next_sibling('dd').get_text(strip=True)
    
    # Add a small delay to be respectful to the server
    time.sleep(random.uniform(1, 3))
    
    return element_data

def extract_css_property_details(property_data, config):
    """Extract detailed information for a CSS property from MDN Web Docs."""
    if not property_data.get('mdn_url'):
        logger.warning(f"No MDN URL for CSS property {property_data.get('name')}")
        return property_data
    
    url = property_data['mdn_url']
    logger.info(f"Fetching details for CSS property {property_data['name']} from {url}")
    
    html_content = fetch_page(url)
    if not html_content:
        return property_data
    
    soup = BeautifulSoup(html_content, 'html.parser')
    
    # Extract description
    description_section = soup.select_one('article section')
    if description_section:
        description = description_section.get_text(strip=True)
        property_data['description'] = description
    
    # Extract specification URL
    spec_link = soup.select_one('a[href*="w3.org/TR/"]')
    if spec_link:
        property_data['spec_url'] = spec_link['href']
    
    # Extract syntax
    syntax_section = soup.find(string=lambda text: 'Syntax' in text if text else False)
    if syntax_section:
        syntax_parent = syntax_section.find_parent('h2')
        if syntax_parent:
            syntax_code = syntax_parent.find_next('pre')
            if syntax_code:
                property_data['syntax'] = syntax_code.get_text(strip=True)
    
    # Extract values
    values = []
    values_section = soup.find(string=lambda text: 'Values' in text if text else False)
    if values_section:
        values_parent = values_section.find_parent('h2')
        if values_parent:
            value_dts = values_parent.find_next('dl').find_all('dt')
            for dt in value_dts:
                value_name = dt.get_text(strip=True)
                value_desc = dt.find_next_sibling('dd').get_text(strip=True) if dt.find_next_sibling('dd') else ""
                values.append({
                    'value': value_name,
                    'description': value_desc
                })
    
    if values:
        property_data['values'] = values
    
    # Extract formal definition
    formal_def = {}
    
    initial_value = soup.find(string=lambda text: 'Initial value' in text if text else False)
    if initial_value:
        initial_parent = initial_value.find_parent('dt')
        if initial_parent and initial_parent.find_next_sibling('dd'):
            formal_def['initial_value'] = initial_parent.find_next_sibling('dd').get_text(strip=True)
    
    applies_to = soup.find(string=lambda text: 'Applies to' in text if text else False)
    if applies_to:
        applies_parent = applies_to.find_parent('dt')
        if applies_parent and applies_parent.find_next_sibling('dd'):
            formal_def['applies_to'] = applies_parent.find_next_sibling('dd').get_text(strip=True)
    
    inherited = soup.find(string=lambda text: 'Inherited' in text if text else False)
    if inherited:
        inherited_parent = inherited.find_parent('dt')
        if inherited_parent and inherited_parent.find_next_sibling('dd'):
            formal_def['inherited'] = inherited_parent.find_next_sibling('dd').get_text(strip=True)
    
    if formal_def:
        property_data['formal_definition'] = formal_def
    
    # Add a small delay to be respectful to the server
    time.sleep(random.uniform(1, 3))
    
    return property_data

def extract_js_object_details(object_data, config):
    """Extract detailed information for a JavaScript object from MDN Web Docs."""
    if not object_data.get('mdn_url'):
        logger.warning(f"No MDN URL for JS object {object_data.get('name')}")
        return object_data
    
    url = object_data['mdn_url']
    logger.info(f"Fetching details for JS object {object_data['name']} from {url}")
    
    html_content = fetch_page(url)
    if not html_content:
        return object_data
    
    soup = BeautifulSoup(html_content, 'html.parser')
    
    # Extract description
    description_section = soup.select_one('article section')
    if description_section:
        description = description_section.get_text(strip=True)
        object_data['description'] = description
    
    # Extract specification URL
    spec_link = soup.select_one('a[href*="tc39.es/ecma262/"]')
    if spec_link:
        object_data['spec_url'] = spec_link['href']
    
    # Extract constructor syntax
    constructor_section = soup.find(string=lambda text: 'Constructor' in text if text else False)
    if constructor_section:
        constructor_parent = constructor_section.find_parent('h2')
        if constructor_parent:
            constructor_code = constructor_parent.find_next('pre')
            if constructor_code:
                object_data['constructor_syntax'] = constructor_code.get_text(strip=True)
    
    # Add a small delay to be respectful to the server
    time.sleep(random.uniform(1, 3))
    
    return object_data

def main():
    """Main function to extract detailed data from MDN Web Docs."""
    logger.info("Starting extraction from MDN Web Docs")
    
    # Load configuration
    config = load_config()
    
    # Base directory for data
    output_dir = Path(__file__).parent.parent / 'output' / 'extracted'
    os.makedirs(output_dir, exist_ok=True)
    
    # Create sample data if files don't exist
    html_elements_file = output_dir / 'html_elements.json'
    css_properties_file = output_dir / 'css_properties.json'
    js_data_file = output_dir / 'js_data.json'
    
    # If files don't exist, create sample data with just a few elements
    if not html_elements_file.exists():
        sample_html = [
            {"tag_name": "div", "mdn_url": "https://developer.mozilla.org/en-US/docs/Web/HTML/Element/div"},
            {"tag_name": "span", "mdn_url": "https://developer.mozilla.org/en-US/docs/Web/HTML/Element/span"},
            {"tag_name": "a", "mdn_url": "https://developer.mozilla.org/en-US/docs/Web/HTML/Element/a"}
        ]
        with open(html_elements_file, 'w', encoding='utf-8') as f:
            json.dump(sample_html, f, indent=2)
    
    if not css_properties_file.exists():
        sample_css = [
            {"name": "color", "mdn_url": "https://developer.mozilla.org/en-US/docs/Web/CSS/color"},
            {"name": "margin", "mdn_url": "https://developer.mozilla.org/en-US/docs/Web/CSS/margin"},
            {"name": "display", "mdn_url": "https://developer.mozilla.org/en-US/docs/Web/CSS/display"}
        ]
        with open(css_properties_file, 'w', encoding='utf-8') as f:
            json.dump(sample_css, f, indent=2)
    
    if not js_data_file.exists():
        sample_js = {
            "built_in_objects": [
                {"name": "Array", "mdn_url": "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array"},
                {"name": "String", "mdn_url": "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String"},
                {"name": "Object", "mdn_url": "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object"}
            ],
            "statements": [],
            "operators": []
        }
        with open(js_data_file, 'w', encoding='utf-8') as f:
            json.dump(sample_js, f, indent=2)
    
    # Load extracted data
    html_elements = load_extracted_data(html_elements_file)
    css_properties = load_extracted_data(css_properties_file)
    js_data = load_extracted_data(js_data_file)
    
    # Extract detailed information for HTML elements
    enriched_html_elements = []
    for element in html_elements:
        enriched_element = extract_html_element_details(element, config)
        enriched_html_elements.append(enriched_element)
    
    # Extract detailed information for CSS properties
    enriched_css_properties = []
    for prop in css_properties:
        enriched_prop = extract_css_property_details(prop, config)
        enriched_css_properties.append(enriched_prop)
    
    # Extract detailed information for JavaScript objects
    enriched_js_objects = []
    # Handle js_data as either a dict with built_in_objects or a list
    if isinstance(js_data, dict) and 'built_in_objects' in js_data:
        js_objects = js_data['built_in_objects']
    else:
        # If js_data is a list or doesn't have built_in_objects, use it directly
        js_objects = js_data if isinstance(js_data, list) else []
    
    for obj in js_objects:
        enriched_obj = extract_js_object_details(obj, config)
        enriched_js_objects.append(enriched_obj)
    
    # Update JS data with enriched objects
    if isinstance(js_data, dict):
        enriched_js_data = js_data.copy()
        enriched_js_data['built_in_objects'] = enriched_js_objects
    else:
        # If js_data was a list, create a proper structure
        enriched_js_data = {
            'built_in_objects': enriched_js_objects,
            'statements': [],
            'operators': []
        }
    
    # Save enriched data
    with open(output_dir / 'html_elements_enriched.json', 'w', encoding='utf-8') as f:
        json.dump(enriched_html_elements, f, indent=2)
    
    with open(output_dir / 'css_properties_enriched.json', 'w', encoding='utf-8') as f:
        json.dump(enriched_css_properties, f, indent=2)
    
    with open(output_dir / 'js_data_enriched.json', 'w', encoding='utf-8') as f:
        json.dump(enriched_js_data, f, indent=2)
    
    logger.info("Extraction from MDN Web Docs completed")

if __name__ == "__main__":
    main()

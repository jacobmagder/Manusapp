#!/usr/bin/env python3
"""
HTML/CSS/JS Web Standards Application
A searchable interface for the normalized web standards data.
"""

import os
import json
from pathlib import Path
from flask import Flask, render_template, jsonify, request, send_from_directory

app = Flask(__name__)

# Load normalized data
def load_data():
    data_path = Path(__file__).parent / 'output' / 'normalized.json'
    try:
        with open(data_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"Error loading data: {e}")
        return {
            "metadata": {"version": "unknown", "sources_used": []},
            "html": {"elements": [], "attributes": {"global": [], "event_handlers": []}},
            "css": {"properties": [], "selectors": [], "at_rules": [], "data_types": [], "units": [], "functions": []},
            "javascript": {"core_language": {"keywords": [], "operators": [], "statements": [], "data_types_primitive": [], "built_in_objects": []}, "web_apis": {"interfaces": [], "events": []}}
        }

# Global data variable
web_standards_data = load_data()

@app.route('/')
def index():
    """Render the main application page."""
    return render_template('index.html', 
                          version=web_standards_data.get('metadata', {}).get('version', 'unknown'),
                          html_count=len(web_standards_data.get('html', {}).get('elements', [])),
                          css_count=len(web_standards_data.get('css', {}).get('properties', [])),
                          js_count=len(web_standards_data.get('javascript', {}).get('core_language', {}).get('built_in_objects', [])))

@app.route('/api/data')
def get_data():
    """API endpoint to get filtered data."""
    category = request.args.get('category', 'all')
    query = request.args.get('query', '').lower()
    
    result = {
        "html_elements": [],
        "css_properties": [],
        "js_objects": []
    }
    
    # Filter HTML elements
    if category in ['all', 'html']:
        html_elements = web_standards_data.get('html', {}).get('elements', [])
        if query:
            result["html_elements"] = [elem for elem in html_elements 
                                      if query in elem.get('tag_name', '').lower() 
                                      or query in elem.get('description', '').lower()]
        else:
            result["html_elements"] = html_elements
    
    # Filter CSS properties
    if category in ['all', 'css']:
        css_properties = web_standards_data.get('css', {}).get('properties', [])
        if query:
            result["css_properties"] = [prop for prop in css_properties 
                                       if query in prop.get('name', '').lower() 
                                       or query in prop.get('description', '').lower()]
        else:
            result["css_properties"] = css_properties
    
    # Filter JS objects
    if category in ['all', 'js']:
        js_objects = web_standards_data.get('javascript', {}).get('core_language', {}).get('built_in_objects', [])
        if query:
            result["js_objects"] = [obj for obj in js_objects 
                                   if query in obj.get('name', '').lower() 
                                   or query in obj.get('description', '').lower()]
        else:
            result["js_objects"] = js_objects
    
    return jsonify(result)

@app.route('/api/changelog')
def get_changelog():
    """API endpoint to get changelog data."""
    changelog = web_standards_data.get('changelog', [])
    return jsonify(changelog)

@app.route('/api/details/<category>/<name>')
def get_details(category, name):
    """API endpoint to get detailed information for a specific item."""
    if category == 'html':
        elements = web_standards_data.get('html', {}).get('elements', [])
        for elem in elements:
            if elem.get('tag_name') == name:
                return jsonify(elem)
    
    elif category == 'css':
        properties = web_standards_data.get('css', {}).get('properties', [])
        for prop in properties:
            if prop.get('name') == name:
                return jsonify(prop)
    
    elif category == 'js':
        objects = web_standards_data.get('javascript', {}).get('core_language', {}).get('built_in_objects', [])
        for obj in objects:
            if obj.get('name') == name:
                return jsonify(obj)
    
    return jsonify({"error": "Item not found"})

@app.route('/static/<path:path>')
def send_static(path):
    """Serve static files."""
    return send_from_directory('static', path)

if __name__ == '__main__':
    # Create templates and static directories if they don't exist
    os.makedirs(Path(__file__).parent / 'templates', exist_ok=True)
    os.makedirs(Path(__file__).parent / 'static', exist_ok=True)
    
    # Run the application
    app.run(host='0.0.0.0', port=5000, debug=True)

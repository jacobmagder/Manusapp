# Web Standards Data Pipeline

A comprehensive system for extracting, structuring, maintaining, and presenting authoritative data on HTML, CSS, and JavaScript standards.

## Overview

This pipeline extracts data from various sources (primarily MDN), normalizes it into a consistent schema, and provides both data exports and a searchable web application for exploring web standards.

## Features

- **Data Extraction**: Pulls data from MDN Browser Compatibility Data and MDN Web Docs
- **Data Normalization**: Transforms extracted data into a unified schema
- **Data Export**: Exports data to JSON and CSV formats
- **Change Detection**: Tracks changes between pipeline runs
- **Web Application**: Provides a searchable interface for exploring web standards data

## Directory Structure

```
web_standards_pipeline/
├── app.py                 # Web application
├── config/                # Configuration files
│   └── sources.json       # Data source URLs and paths
├── data/                  # Raw data storage
├── logs/                  # Log files
├── output/                # Processed data output
│   ├── csv/               # CSV exports
│   ├── extracted/         # Extracted raw data
│   └── normalized.json    # Unified schema data
├── runner.py              # Main pipeline runner
├── scripts/               # Pipeline scripts
│   ├── export_csv.py      # CSV export script
│   ├── extract_mdn_bcd.py # MDN BCD extraction script
│   ├── extract_mdn_docs.py # MDN Web Docs extraction script
│   ├── normalize.py       # Data normalization script
│   └── setup_sources.py   # Data source setup script
├── static/                # Web app static files
└── templates/             # Web app templates
    └── index.html         # Main web app page
```

## Installation

1. Clone this repository:
   ```
   git clone https://github.com/yourusername/web_standards_pipeline.git
   cd web_standards_pipeline
   ```

2. Install required dependencies:
   ```
   pip install requests beautifulsoup4 deepdiff flask
   ```

## Usage

### Running the Full Pipeline

To run the complete pipeline (setup, extraction, normalization, and export):

```
python runner.py
```

This will:
1. Clone or update data source repositories
2. Extract data from MDN BCD and MDN Web Docs
3. Normalize the data into a unified schema
4. Export the data to CSV format
5. Detect and log changes from previous runs

### Running Individual Components

You can run specific parts of the pipeline using command-line arguments:

```
python runner.py --skip-setup        # Skip cloning/updating repositories
python runner.py --skip-extraction   # Skip data extraction
python runner.py --skip-normalization # Skip data normalization
python runner.py --skip-export       # Skip CSV export
```

### Running the Web Application

To start the web application for browsing the data:

```
python app.py
```

Then open a web browser and navigate to:
```
http://localhost:5000
```

## Data Schema

The normalized data follows a unified schema that includes:

- **HTML Elements**: Tag names, descriptions, content models, DOM interfaces, etc.
- **CSS Properties**: Names, descriptions, syntax, values, formal definitions, etc.
- **JavaScript Objects**: Built-in objects, methods, properties, etc.

For the complete schema details, refer to the original guide or examine the `normalized.json` file.

## Extending the Pipeline

### Adding New Data Sources

1. Update `config/sources.json` with the new source information
2. Create a new extraction script in the `scripts/` directory
3. Update `runner.py` to include the new extraction step

### Modifying the Schema

1. Update the normalization logic in `scripts/normalize.py`
2. Ensure the web application in `app.py` is updated to handle the schema changes

## Troubleshooting

### Common Issues

- **Missing Data**: Ensure all extraction scripts have run successfully
- **Port Conflicts**: If port 5000 is in use, kill the process or change the port in `app.py`
- **Extraction Errors**: Check network connectivity and source availability

### Logs

Check the log files in the `logs/` directory for detailed error information:
- `extraction.log`: Data extraction logs
- `normalization.log`: Data normalization logs
- `export.log`: Data export logs
- `runner_YYYYMMDD.log`: Full pipeline run logs
- `changes_YYYYMMDD.json`: Detected changes between runs

## License

This project is open source and available under the MIT License.

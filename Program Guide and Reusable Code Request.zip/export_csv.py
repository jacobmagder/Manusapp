#!/usr/bin/env python3
"""
Export normalized data to different formats.
"""

import os
import json
import logging
import csv
from pathlib import Path

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(Path(__file__).parent.parent / 'logs' / 'export.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('export')

def load_normalized_data():
    """Load normalized data from JSON file."""
    normalized_path = Path(__file__).parent.parent / 'output' / 'normalized.json'
    try:
        with open(normalized_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Failed to load normalized data: {e}")
        return None

def export_to_csv(data, output_dir):
    """Export data to CSV files."""
    logger.info("Exporting data to CSV files")
    
    os.makedirs(output_dir, exist_ok=True)
    
    # Export HTML elements
    html_elements = data.get('html', {}).get('elements', [])
    if html_elements:
        html_csv_path = output_dir / 'html_elements.csv'
        try:
            with open(html_csv_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                # Write header
                writer.writerow(['Tag Name', 'Description', 'MDN URL', 'Spec URL', 'DOM Interface', 'Deprecated'])
                
                # Write data
                for element in html_elements:
                    writer.writerow([
                        element.get('tag_name', ''),
                        element.get('description', '')[:100] + '...' if element.get('description', '') else '',
                        element.get('mdn_url', ''),
                        element.get('spec_url', ''),
                        element.get('dom_interface', ''),
                        'Yes' if element.get('deprecated', {}).get('status', False) else 'No'
                    ])
            
            logger.info(f"Exported {len(html_elements)} HTML elements to CSV")
        except Exception as e:
            logger.error(f"Failed to export HTML elements to CSV: {e}")
    
    # Export CSS properties
    css_properties = data.get('css', {}).get('properties', [])
    if css_properties:
        css_csv_path = output_dir / 'css_properties.csv'
        try:
            with open(css_csv_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                # Write header
                writer.writerow(['Name', 'Description', 'MDN URL', 'Spec URL', 'Initial Value', 'Inherited'])
                
                # Write data
                for prop in css_properties:
                    writer.writerow([
                        prop.get('name', ''),
                        prop.get('description', '')[:100] + '...' if prop.get('description', '') else '',
                        prop.get('mdn_url', ''),
                        prop.get('spec_url', ''),
                        prop.get('initial_value', ''),
                        'Yes' if prop.get('inherited', False) else 'No'
                    ])
            
            logger.info(f"Exported {len(css_properties)} CSS properties to CSV")
        except Exception as e:
            logger.error(f"Failed to export CSS properties to CSV: {e}")
    
    # Export JS built-in objects
    js_objects = data.get('javascript', {}).get('core_language', {}).get('built_in_objects', [])
    if js_objects:
        js_csv_path = output_dir / 'js_objects.csv'
        try:
            with open(js_csv_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                # Write header
                writer.writerow(['Name', 'Type', 'Description', 'MDN URL', 'Spec URL', 'Instance Methods Count', 'Instance Properties Count'])
                
                # Write data
                for obj in js_objects:
                    writer.writerow([
                        obj.get('name', ''),
                        obj.get('type', ''),
                        obj.get('description', '')[:100] + '...' if obj.get('description', '') else '',
                        obj.get('mdn_url', ''),
                        obj.get('spec_url', ''),
                        len(obj.get('instance_methods', [])),
                        len(obj.get('instance_properties', []))
                    ])
            
            logger.info(f"Exported {len(js_objects)} JS objects to CSV")
        except Exception as e:
            logger.error(f"Failed to export JS objects to CSV: {e}")

def main():
    """Main function to export normalized data to different formats."""
    logger.info("Starting export of normalized data")
    
    # Load normalized data
    data = load_normalized_data()
    if not data:
        logger.error("No normalized data to export")
        return
    
    # Export to CSV
    csv_dir = Path(__file__).parent.parent / 'output' / 'csv'
    export_to_csv(data, csv_dir)
    
    logger.info("Export completed")

if __name__ == "__main__":
    main()

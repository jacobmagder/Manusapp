#!/usr/bin/env python3
"""
Extract data from MDN Browser Compatibility Data (BCD) repository.
Focuses on HTML, CSS, and JavaScript data.
"""

import os
import json
import logging
from pathlib import Path

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(Path(__file__).parent.parent / 'logs' / 'extraction.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('extract_mdn_bcd')

def load_json_file(file_path):
    """Load and parse a JSON file."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Failed to load JSON file {file_path}: {e}")
        return None

def extract_html_elements(bcd_dir):
    """Extract HTML elements data from BCD."""
    logger.info("Extracting HTML elements data")
    
    html_path = bcd_dir / 'html' / 'elements'
    if not html_path.exists():
        logger.error(f"HTML elements directory not found: {html_path}")
        return []
    
    elements = []
    
    # Process each element file
    for file_path in html_path.glob('*.json'):
        element_name = file_path.stem
        logger.info(f"Processing HTML element: {element_name}")
        
        data = load_json_file(file_path)
        if not data:
            continue
        
        # Extract element data
        element_data = {
            'tag_name': element_name,
            'mdn_url': data.get('html', {}).get('elements', {}).get(element_name, {}).get('__compat', {}).get('mdn_url', ''),
            'browser_compatibility': data.get('html', {}).get('elements', {}).get(element_name, {}).get('__compat', {}).get('support', {})
        }
        
        elements.append(element_data)
    
    logger.info(f"Extracted {len(elements)} HTML elements")
    return elements

def extract_css_properties(bcd_dir):
    """Extract CSS properties data from BCD."""
    logger.info("Extracting CSS properties data")
    
    css_path = bcd_dir / 'css' / 'properties'
    if not css_path.exists():
        logger.error(f"CSS properties directory not found: {css_path}")
        return []
    
    properties = []
    
    # Process each property file
    for file_path in css_path.glob('*.json'):
        property_name = file_path.stem
        logger.info(f"Processing CSS property: {property_name}")
        
        data = load_json_file(file_path)
        if not data:
            continue
        
        # Extract property data
        property_data = {
            'name': property_name,
            'mdn_url': data.get('css', {}).get('properties', {}).get(property_name, {}).get('__compat', {}).get('mdn_url', ''),
            'browser_compatibility': data.get('css', {}).get('properties', {}).get(property_name, {}).get('__compat', {}).get('support', {})
        }
        
        properties.append(property_data)
    
    logger.info(f"Extracted {len(properties)} CSS properties")
    return properties

def extract_js_data(bcd_dir):
    """Extract JavaScript data from BCD."""
    logger.info("Extracting JavaScript data")
    
    js_path = bcd_dir / 'javascript'
    if not js_path.exists():
        logger.error(f"JavaScript directory not found: {js_path}")
        return {
            'built_in_objects': [],
            'statements': [],
            'operators': []
        }
    
    js_data = {
        'built_in_objects': [],
        'statements': [],
        'operators': []
    }
    
    # Extract built-in objects
    builtins_path = js_path / 'builtins'
    if builtins_path.exists():
        for file_path in builtins_path.glob('*.json'):
            object_name = file_path.stem
            logger.info(f"Processing JS built-in object: {object_name}")
            
            data = load_json_file(file_path)
            if not data:
                continue
            
            # Extract object data
            object_data = {
                'name': object_name,
                'mdn_url': data.get('javascript', {}).get('builtins', {}).get(object_name, {}).get('__compat', {}).get('mdn_url', ''),
                'browser_compatibility': data.get('javascript', {}).get('builtins', {}).get(object_name, {}).get('__compat', {}).get('support', {}),
                'methods': [],
                'properties': []
            }
            
            # Extract methods and properties
            for key, value in data.get('javascript', {}).get('builtins', {}).get(object_name, {}).items():
                if key != '__compat':
                    if isinstance(value, dict) and '__compat' in value:
                        member_type = 'methods' if '(' in key else 'properties'
                        member_data = {
                            'name': key,
                            'mdn_url': value.get('__compat', {}).get('mdn_url', ''),
                            'browser_compatibility': value.get('__compat', {}).get('support', {})
                        }
                        object_data[member_type].append(member_data)
            
            js_data['built_in_objects'].append(object_data)
    
    # Extract statements
    statements_path = js_path / 'statements'
    if statements_path.exists():
        for file_path in statements_path.glob('*.json'):
            statement_name = file_path.stem
            logger.info(f"Processing JS statement: {statement_name}")
            
            data = load_json_file(file_path)
            if not data:
                continue
            
            # Extract statement data
            statement_data = {
                'name': statement_name,
                'mdn_url': data.get('javascript', {}).get('statements', {}).get(statement_name, {}).get('__compat', {}).get('mdn_url', ''),
                'browser_compatibility': data.get('javascript', {}).get('statements', {}).get(statement_name, {}).get('__compat', {}).get('support', {})
            }
            
            js_data['statements'].append(statement_data)
    
    # Extract operators
    operators_path = js_path / 'operators'
    if operators_path.exists():
        for file_path in operators_path.glob('*.json'):
            operator_name = file_path.stem
            logger.info(f"Processing JS operator: {operator_name}")
            
            data = load_json_file(file_path)
            if not data:
                continue
            
            # Extract operator data
            operator_data = {
                'name': operator_name,
                'mdn_url': data.get('javascript', {}).get('operators', {}).get(operator_name, {}).get('__compat', {}).get('mdn_url', ''),
                'browser_compatibility': data.get('javascript', {}).get('operators', {}).get(operator_name, {}).get('__compat', {}).get('support', {})
            }
            
            js_data['operators'].append(operator_data)
    
    logger.info(f"Extracted {len(js_data['built_in_objects'])} JS built-in objects, "
                f"{len(js_data['statements'])} statements, and {len(js_data['operators'])} operators")
    
    return js_data

def main():
    """Main function to extract data from MDN BCD."""
    logger.info("Starting extraction from MDN Browser Compatibility Data")
    
    # Base directory for data
    data_dir = Path(__file__).parent.parent / 'data'
    bcd_dir = data_dir / 'mdn_bcd'
    
    if not bcd_dir.exists():
        logger.error(f"MDN BCD directory not found: {bcd_dir}")
        return
    
    # Extract data
    html_elements = extract_html_elements(bcd_dir)
    css_properties = extract_css_properties(bcd_dir)
    js_data = extract_js_data(bcd_dir)
    
    # Save extracted data
    output_dir = Path(__file__).parent.parent / 'output' / 'extracted'
    os.makedirs(output_dir, exist_ok=True)
    
    with open(output_dir / 'html_elements.json', 'w', encoding='utf-8') as f:
        json.dump(html_elements, f, indent=2)
    
    with open(output_dir / 'css_properties.json', 'w', encoding='utf-8') as f:
        json.dump(css_properties, f, indent=2)
    
    with open(output_dir / 'js_data.json', 'w', encoding='utf-8') as f:
        json.dump(js_data, f, indent=2)
    
    logger.info("Extraction from MDN BCD completed")

if __name__ == "__main__":
    main()

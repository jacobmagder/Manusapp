#!/usr/bin/env python3
"""
Normalize and unify extracted data into a consistent schema.
"""

import os
import json
import logging
from pathlib import Path
from datetime import datetime

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(Path(__file__).parent.parent / 'logs' / 'normalization.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('normalize')

def load_extracted_data(file_path):
    """Load extracted data from a JSON file."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Failed to load data from {file_path}: {e}")
        return None

def normalize_html_elements(html_elements):
    """Normalize HTML elements data to the unified schema."""
    logger.info("Normalizing HTML elements data")
    
    normalized_elements = []
    
    for element in html_elements:
        tag_name = element.get('tag_name', '')
        
        # Skip if no tag name
        if not tag_name:
            continue
        
        normalized_element = {
            'tag_name': tag_name,
            'description': element.get('description', ''),
            'mdn_url': element.get('mdn_url', ''),
            'spec_url': element.get('spec_url', ''),
            'categories': [],
            'content_model': {
                'permitted_parents': [],
                'permitted_children': [],
                'detailed_description': ''
            },
            'attributes': {
                'global': True,
                'specific': [],
                'event_handlers': True
            },
            'dom_interface': element.get('dom_interface', ''),
            'deprecated': {
                'status': False,
                'alternative': ''
            },
            'browser_compatibility': element.get('browser_compatibility', {})
        }
        
        # Process content model if available
        content_model = element.get('content_model', {})
        if content_model:
            # Extract categories from content model text
            categories_text = content_model.get('categories', '')
            if categories_text:
                # Simple extraction of categories from text
                categories = [cat.strip() for cat in categories_text.split(',')]
                normalized_element['categories'] = categories
            
            # Extract permitted parents and children
            normalized_element['content_model']['permitted_parents'] = content_model.get('permitted_parents', '')
            normalized_element['content_model']['permitted_children'] = content_model.get('permitted_children', '')
            
            # Combine all content model information for detailed description
            detailed_desc = []
            for key, value in content_model.items():
                if value:
                    detailed_desc.append(f"{key}: {value}")
            
            normalized_element['content_model']['detailed_description'] = '\n'.join(detailed_desc)
        
        normalized_elements.append(normalized_element)
    
    logger.info(f"Normalized {len(normalized_elements)} HTML elements")
    return normalized_elements

def normalize_css_properties(css_properties):
    """Normalize CSS properties data to the unified schema."""
    logger.info("Normalizing CSS properties data")
    
    normalized_properties = []
    
    for prop in css_properties:
        name = prop.get('name', '')
        
        # Skip if no name
        if not name:
            continue
        
        normalized_property = {
            'name': name,
            'description': prop.get('description', ''),
            'mdn_url': prop.get('mdn_url', ''),
            'spec_url': prop.get('spec_url', ''),
            'syntax': prop.get('syntax', ''),
            'initial_value': '',
            'applies_to': '',
            'inherited': False,
            'percentages': '',
            'computed_value': '',
            'animation_type': '',
            'canonical_order': '',
            'logical_property_group': '',
            'values': [],
            'browser_compatibility': prop.get('browser_compatibility', {})
        }
        
        # Process formal definition if available
        formal_def = prop.get('formal_definition', {})
        if formal_def:
            normalized_property['initial_value'] = formal_def.get('initial_value', '')
            normalized_property['applies_to'] = formal_def.get('applies_to', '')
            normalized_property['inherited'] = 'yes' in formal_def.get('inherited', '').lower()
        
        # Process values if available
        values = prop.get('values', [])
        normalized_values = []
        
        for value in values:
            normalized_value = {
                'type': 'keyword',  # Default type
                'value': value.get('value', ''),
                'description': value.get('description', '')
            }
            
            # Try to determine value type
            value_text = value.get('value', '').lower()
            if '<' in value_text and '>' in value_text:
                normalized_value['type'] = 'data_type'
            elif '(' in value_text and ')' in value_text:
                normalized_value['type'] = 'function'
            
            normalized_values.append(normalized_value)
        
        normalized_property['values'] = normalized_values
        
        normalized_properties.append(normalized_property)
    
    logger.info(f"Normalized {len(normalized_properties)} CSS properties")
    return normalized_properties

def normalize_js_data(js_data):
    """Normalize JavaScript data to the unified schema."""
    logger.info("Normalizing JavaScript data")
    
    normalized_js_data = {
        'core_language': {
            'keywords': [],
            'operators': [],
            'statements': [],
            'data_types_primitive': [],
            'built_in_objects': []
        },
        'web_apis': {
            'interfaces': [],
            'events': []
        }
    }
    
    # Normalize built-in objects
    for obj in js_data.get('built_in_objects', []):
        name = obj.get('name', '')
        
        # Skip if no name
        if not name:
            continue
        
        normalized_object = {
            'name': name,
            'type': 'Class',  # Default type
            'description': obj.get('description', ''),
            'constructor_syntax': obj.get('constructor_syntax', ''),
            'mdn_url': obj.get('mdn_url', ''),
            'spec_url': obj.get('spec_url', ''),
            'static_properties': [],
            'static_methods': [],
            'instance_properties': [],
            'instance_methods': [],
            'browser_compatibility': obj.get('browser_compatibility', {})
        }
        
        # Determine object type
        if name in ['Math', 'JSON', 'Reflect', 'Intl']:
            normalized_object['type'] = 'Namespace'
        
        # Process methods
        for method in obj.get('methods', []):
            method_name = method.get('name', '')
            
            # Skip if no name
            if not method_name:
                continue
            
            normalized_method = {
                'name': method_name,
                'type': 'method',
                'description': '',
                'syntax': f"{name}.{method_name}()",
                'parameters': [],
                'return_value': {
                    'type': '',
                    'description': ''
                },
                'mdn_url': method.get('mdn_url', ''),
                'spec_url': '',
                'deprecated': {
                    'status': False,
                    'alternative': ''
                },
                'static': method_name[0].isupper() or method_name.startswith('is'),
                'browser_compatibility': method.get('browser_compatibility', {})
            }
            
            if normalized_method['static']:
                normalized_object['static_methods'].append(normalized_method)
            else:
                normalized_object['instance_methods'].append(normalized_method)
        
        # Process properties
        for prop in obj.get('properties', []):
            prop_name = prop.get('name', '')
            
            # Skip if no name
            if not prop_name:
                continue
            
            normalized_prop = {
                'name': prop_name,
                'type': 'property',
                'description': '',
                'syntax': f"{name}.{prop_name}",
                'mdn_url': prop.get('mdn_url', ''),
                'spec_url': '',
                'deprecated': {
                    'status': False,
                    'alternative': ''
                },
                'static': prop_name[0].isupper(),
                'browser_compatibility': prop.get('browser_compatibility', {})
            }
            
            if normalized_prop['static']:
                normalized_object['static_properties'].append(normalized_prop)
            else:
                normalized_object['instance_properties'].append(normalized_prop)
        
        normalized_js_data['core_language']['built_in_objects'].append(normalized_object)
    
    # Normalize statements
    for statement in js_data.get('statements', []):
        name = statement.get('name', '')
        
        # Skip if no name
        if not name:
            continue
        
        normalized_statement = {
            'name': name,
            'category': 'statement',
            'description': '',
            'syntax_example': name,
            'mdn_url': statement.get('mdn_url', ''),
            'spec_url': '',
            'browser_compatibility': statement.get('browser_compatibility', {})
        }
        
        normalized_js_data['core_language']['statements'].append(normalized_statement)
    
    # Normalize operators
    for operator in js_data.get('operators', []):
        name = operator.get('name', '')
        
        # Skip if no name
        if not name:
            continue
        
        normalized_operator = {
            'name': name,
            'category': 'operator',
            'description': '',
            'syntax_example': name,
            'mdn_url': operator.get('mdn_url', ''),
            'spec_url': '',
            'browser_compatibility': operator.get('browser_compatibility', {})
        }
        
        normalized_js_data['core_language']['operators'].append(normalized_operator)
    
    logger.info(f"Normalized {len(normalized_js_data['core_language']['built_in_objects'])} JS built-in objects, "
                f"{len(normalized_js_data['core_language']['statements'])} statements, and "
                f"{len(normalized_js_data['core_language']['operators'])} operators")
    
    return normalized_js_data

def main():
    """Main function to normalize extracted data."""
    logger.info("Starting normalization of extracted data")
    
    # Base directory for data
    extracted_dir = Path(__file__).parent.parent / 'output' / 'extracted'
    output_dir = Path(__file__).parent.parent / 'output'
    os.makedirs(output_dir, exist_ok=True)
    
    # Load enriched data if available, otherwise fall back to basic extracted data
    html_elements_file = extracted_dir / 'html_elements_enriched.json'
    if not html_elements_file.exists():
        html_elements_file = extracted_dir / 'html_elements.json'
    
    css_properties_file = extracted_dir / 'css_properties_enriched.json'
    if not css_properties_file.exists():
        css_properties_file = extracted_dir / 'css_properties.json'
    
    js_data_file = extracted_dir / 'js_data_enriched.json'
    if not js_data_file.exists():
        js_data_file = extracted_dir / 'js_data.json'
    
    # Load data
    html_elements = load_extracted_data(html_elements_file)
    css_properties = load_extracted_data(css_properties_file)
    js_data = load_extracted_data(js_data_file)
    
    if not html_elements or not css_properties or not js_data:
        logger.error("Failed to load extracted data")
        return
    
    # Normalize data
    normalized_html_elements = normalize_html_elements(html_elements)
    normalized_css_properties = normalize_css_properties(css_properties)
    normalized_js_data = normalize_js_data(js_data)
    
    # Create unified data structure
    normalized_data = {
        "metadata": {
            "version": datetime.now().strftime("%Y-%m-%d"),
            "sources_used": ["mdn_bcd", "mdn_web_docs"]
        },
        "html": {
            "elements": normalized_html_elements,
            "attributes": {
                "global": [],
                "event_handlers": []
            }
        },
        "css": {
            "properties": normalized_css_properties,
            "selectors": [],
            "at_rules": [],
            "data_types": [],
            "units": [],
            "functions": []
        },
        "javascript": normalized_js_data,
        "changelog": []
    }
    
    # Save normalized data
    with open(output_dir / 'normalized.json', 'w', encoding='utf-8') as f:
        json.dump(normalized_data, f, indent=2)
    
    logger.info("Normalization completed")

if __name__ == "__main__":
    main()

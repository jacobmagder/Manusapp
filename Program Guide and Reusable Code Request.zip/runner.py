#!/usr/bin/env python3
"""
Main runner script for the web standards data pipeline.
"""

import os
import sys
import json
import logging
import subprocess
import argparse
from pathlib import Path
from datetime import datetime
from deepdiff import DeepDiff

# Setup logging
log_dir = Path(__file__).parent / 'logs'
os.makedirs(log_dir, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_dir / f'runner_{datetime.now().strftime("%Y%m%d")}.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('runner')

def run_script(script_path, description):
    """Run a Python script and log the result."""
    logger.info(f"Running {description}...")
    
    try:
        result = subprocess.run(
            [sys.executable, script_path],
            capture_output=True,
            text=True,
            check=True
        )
        logger.info(f"{description} completed successfully")
        return True
    except subprocess.CalledProcessError as e:
        logger.error(f"{description} failed: {e.stderr.strip()}")
        return False

def detect_changes():
    """Detect changes between the current and previous normalized data."""
    current_path = Path(__file__).parent / 'output' / 'normalized.json'
    backup_path = Path(__file__).parent / 'output' / 'normalized_previous.json'
    
    if not current_path.exists():
        logger.warning("No current normalized data found")
        return
    
    # Load current data
    try:
        with open(current_path, 'r', encoding='utf-8') as f:
            current_data = json.load(f)
    except Exception as e:
        logger.error(f"Failed to load current normalized data: {e}")
        return
    
    # If no previous data exists, save current as previous and exit
    if not backup_path.exists():
        try:
            with open(backup_path, 'w', encoding='utf-8') as f:
                json.dump(current_data, f, indent=2)
            logger.info("No previous data found, saved current data as previous")
            return
        except Exception as e:
            logger.error(f"Failed to save current data as previous: {e}")
            return
    
    # Load previous data
    try:
        with open(backup_path, 'r', encoding='utf-8') as f:
            previous_data = json.load(f)
    except Exception as e:
        logger.error(f"Failed to load previous normalized data: {e}")
        return
    
    # Compare data
    try:
        diff = DeepDiff(previous_data, current_data, ignore_order=True)
        
        if not diff:
            logger.info("No changes detected between current and previous data")
            return
        
        # Log changes
        changes_log_path = log_dir / f'changes_{datetime.now().strftime("%Y%m%d")}.json'
        with open(changes_log_path, 'w', encoding='utf-8') as f:
            json.dump(diff, f, indent=2)
        
        # Update changelog in current data
        changelog_entries = []
        
        # Process additions
        for path, values in diff.get('dictionary_item_added', {}).items():
            path_parts = path.strip("root[]'").split("']['")
            if len(path_parts) >= 3 and path_parts[0] in ['html', 'css', 'javascript']:
                category = f"{path_parts[0]}_{path_parts[1]}"
                item_name = path_parts[2] if len(path_parts) > 2 else 'unknown'
                
                changelog_entries.append({
                    'date': datetime.now().strftime("%Y-%m-%d"),
                    'type': 'addition',
                    'category': category,
                    'item_name': item_name,
                    'path_in_json': path,
                    'change_details': {
                        'new_value': 'Added new item'
                    },
                    'summary': f"Added new {category}: {item_name}"
                })
        
        # Process modifications
        for path, values in diff.get('values_changed', {}).items():
            path_parts = path.strip("root[]'").split("']['")
            if len(path_parts) >= 3 and path_parts[0] in ['html', 'css', 'javascript']:
                category = f"{path_parts[0]}_{path_parts[1]}"
                item_name = path_parts[2] if len(path_parts) > 2 else 'unknown'
                
                changelog_entries.append({
                    'date': datetime.now().strftime("%Y-%m-%d"),
                    'type': 'modification',
                    'category': category,
                    'item_name': item_name,
                    'path_in_json': path,
                    'change_details': {
                        'old_value': str(values.get('old_value', ''))[:100],
                        'new_value': str(values.get('new_value', ''))[:100]
                    },
                    'summary': f"Modified {category}: {item_name}"
                })
        
        # Process removals
        for path, values in diff.get('dictionary_item_removed', {}).items():
            path_parts = path.strip("root[]'").split("']['")
            if len(path_parts) >= 3 and path_parts[0] in ['html', 'css', 'javascript']:
                category = f"{path_parts[0]}_{path_parts[1]}"
                item_name = path_parts[2] if len(path_parts) > 2 else 'unknown'
                
                changelog_entries.append({
                    'date': datetime.now().strftime("%Y-%m-%d"),
                    'type': 'removal',
                    'category': category,
                    'item_name': item_name,
                    'path_in_json': path,
                    'change_details': {
                        'old_value': 'Removed item'
                    },
                    'summary': f"Removed {category}: {item_name}"
                })
        
        # Update changelog in current data
        current_data['changelog'] = changelog_entries + current_data.get('changelog', [])
        
        # Save updated current data
        with open(current_path, 'w', encoding='utf-8') as f:
            json.dump(current_data, f, indent=2)
        
        # Save current data as previous for next run
        with open(backup_path, 'w', encoding='utf-8') as f:
            json.dump(current_data, f, indent=2)
        
        logger.info(f"Detected and logged {len(changelog_entries)} changes")
        
    except Exception as e:
        logger.error(f"Failed to detect changes: {e}")

def main():
    """Main function to run the entire pipeline."""
    parser = argparse.ArgumentParser(description='Run the web standards data pipeline')
    parser.add_argument('--skip-setup', action='store_true', help='Skip the setup step')
    parser.add_argument('--skip-extraction', action='store_true', help='Skip the extraction step')
    parser.add_argument('--skip-normalization', action='store_true', help='Skip the normalization step')
    parser.add_argument('--skip-export', action='store_true', help='Skip the export step')
    args = parser.parse_args()
    
    logger.info("Starting web standards data pipeline")
    
    # Get script paths
    scripts_dir = Path(__file__).parent / 'scripts'
    setup_script = scripts_dir / 'setup_sources.py'
    extract_bcd_script = scripts_dir / 'extract_mdn_bcd.py'
    extract_docs_script = scripts_dir / 'extract_mdn_docs.py'
    normalize_script = scripts_dir / 'normalize.py'
    export_csv_script = scripts_dir / 'export_csv.py'
    
    # Create necessary directories
    os.makedirs(Path(__file__).parent / 'output' / 'extracted', exist_ok=True)
    
    # Run setup
    if not args.skip_setup:
        if not run_script(setup_script, "setup of data sources"):
            logger.error("Pipeline failed at setup step")
            return
    
    # Run extraction
    if not args.skip_extraction:
        if not run_script(extract_bcd_script, "extraction from MDN BCD"):
            logger.error("Pipeline failed at BCD extraction step")
            return
        
        if not run_script(extract_docs_script, "extraction from MDN Web Docs"):
            logger.error("Pipeline failed at Web Docs extraction step")
            return
    
    # Run normalization
    if not args.skip_normalization:
        if not run_script(normalize_script, "normalization"):
            logger.error("Pipeline failed at normalization step")
            return
    
    # Run export
    if not args.skip_export:
        if not run_script(export_csv_script, "CSV export"):
            logger.error("Pipeline failed at CSV export step")
            return
    
    # Detect changes
    detect_changes()
    
    logger.info("Pipeline completed successfully")

if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
Setup script to clone or update data source repositories.
"""

import os
import json
import subprocess
import logging
from pathlib import Path

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(Path(__file__).parent.parent / 'logs' / 'setup.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('setup_sources')

def load_config():
    """Load configuration from sources.json file."""
    config_path = Path(__file__).parent.parent / 'config' / 'sources.json'
    try:
        with open(config_path, 'r') as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Failed to load configuration: {e}")
        raise

def clone_or_update_repo(repo_url, target_dir):
    """Clone a repository if it doesn't exist, or update it if it does."""
    target_path = Path(target_dir)
    
    if (target_path / '.git').exists():
        # Repository exists, update it
        logger.info(f"Updating repository in {target_dir}")
        try:
            result = subprocess.run(
                ['git', 'pull', 'origin', 'main'],
                cwd=target_dir,
                capture_output=True,
                text=True,
                check=True
            )
            logger.info(f"Update result: {result.stdout.strip()}")
            return True
        except subprocess.CalledProcessError as e:
            # If main branch doesn't exist, try master
            try:
                result = subprocess.run(
                    ['git', 'pull', 'origin', 'master'],
                    cwd=target_dir,
                    capture_output=True,
                    text=True,
                    check=True
                )
                logger.info(f"Update result: {result.stdout.strip()}")
                return True
            except subprocess.CalledProcessError as e2:
                logger.error(f"Failed to update repository: {e2.stderr.strip()}")
                return False
    else:
        # Repository doesn't exist, clone it
        logger.info(f"Cloning repository {repo_url} to {target_dir}")
        try:
            os.makedirs(os.path.dirname(target_dir), exist_ok=True)
            result = subprocess.run(
                ['git', 'clone', repo_url, target_dir],
                capture_output=True,
                text=True,
                check=True
            )
            logger.info(f"Clone result: {result.stdout.strip()}")
            return True
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to clone repository: {e.stderr.strip()}")
            return False

def main():
    """Main function to setup or update all source repositories."""
    logger.info("Starting setup of data sources")
    
    # Load configuration
    config = load_config()
    
    # Base directory for data
    data_dir = Path(__file__).parent.parent / 'data'
    os.makedirs(data_dir, exist_ok=True)
    
    # Clone or update MDN Browser Compatibility Data
    mdn_bcd_dir = data_dir / 'mdn_bcd'
    clone_or_update_repo(config['mdn']['bcd_repo'], mdn_bcd_dir)
    
    # Clone or update W3C Webref
    w3c_webref_dir = data_dir / 'w3c_webref'
    clone_or_update_repo(config['w3c']['webref_repo'], w3c_webref_dir)
    
    logger.info("Setup of data sources completed")

if __name__ == "__main__":
    main()
